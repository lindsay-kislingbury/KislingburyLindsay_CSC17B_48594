/* 
 * File:   main.cpp
 * Author: Lindsay Kislingbury
 * Purpose: Lab Tracker V1
 * Created on September 25, 2021, 1:11 PM
 */

//System Libraries
#include <cstdlib>
#include <iostream>
using namespace std;
//User Libraries
#include "Student.h"
#include "Section.h"
#include "StudentData.h"

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    StudentData data;
   
    //Get inputs
    cout<<"There are "<<data.getNumStudents()<<" students"<<endl;
    
    
    
    
    
    
    //Exit
    return 0;
}

