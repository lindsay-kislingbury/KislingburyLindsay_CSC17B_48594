/* 
 * File:   main.cpp
 * Author: Lindsay Kislingbury
 * Purpose: Hello World Program
 * Created on September 2, 2021, 8:12 PM
 */

//System Libraries
#include <cstdlib>
#include <iostream>
using namespace std;

//Execution Begins Here!
int main(int argc, char** argv) {

    //Display Message
    cout<<"Hello World! <(^.^)>";
    
    //Exit
    return 0;
}

